#My first Python argument
#06/01/2017
#CTI-110 Tutorial 1 - My First Python Program
#Andrae Hernandez-Diaz
#
print ('This is a test of Idle.')
