# Calculating Distance Traveled
# Date: 06/07/2017
# CTI-110 M2HW1 - Distance Traveled
# Hernandez-Diaz, Andrae
#
distance = float(input('Enter distance: '))
miles_hours6 = 70 * 6
miles_hours10 = 70 * 10
miles_hours15 = 70 * 15
total = miles_hours6 / distance, miles_hours10 / distance, miles_hours15 / distance
print('Distance Traveled is', total)
