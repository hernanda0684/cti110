# Creating a Sales Prediction
# Date: 06/06/2017
# CTI-110 M2T1 - Sales Prediction
# Hernandez-Diaz, Andrae
#
total_sales = float(input('Enter the projected sales: '))
profit = total_sales * 0.23
print('The profit is $', profit)
